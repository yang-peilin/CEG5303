import tkinter as tk
from tkinter import scrolledtext
from gpt4all import GPT4All

class ChatbotGUI:
    def __init__(self, master):
        self.master = master
        master.title("GPT4All Chatbot GUI")

        self.model = GPT4All("orca-mini-3b-gguf2-q4_0.gguf")

        self.text_area = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=60, height=20)
        self.text_area.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

        self.input_entry = tk.Entry(master, width=50)
        self.input_entry.grid(row=1, column=0, padx=10, pady=10)

        self.submit_button = tk.Button(master, text="Submit", command=self.submit)
        self.submit_button.grid(row=1, column=1, padx=10, pady=10)

        self.clear_button = tk.Button(master, text="Clear", command=self.clear)
        self.clear_button.grid(row=1, column=2, padx=10, pady=10)

    def submit(self):
        user_input = self.input_entry.get()
        self.text_area.insert(tk.END, f"\n> {user_input}\n")
        self.input_entry.delete(0, tk.END)

        with self.model.chat_session():
            response = self.model.generate(user_input, max_tokens=1024)
            self.text_area.insert(tk.END, response + "\n")

    def clear(self):
        self.text_area.delete(1.0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatbotGUI(root)
    root.mainloop()
