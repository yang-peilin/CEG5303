import tkinter as tk
from tkinter import scrolledtext
from tkinter import messagebox
from gpt4all import GPT4All
from chatbot import *
import pickle
import os
import tensorflow.compat.v1 as tf
import copy
import argparse

# 加载模型参数
def load_model_params(save_dir):
    model_path, config_path, vocab_path = get_paths(save_dir)
    with open(config_path, 'rb') as f:
        saved_args = pickle.load(f)
    with open(vocab_path, 'rb') as f:
        chars, vocab = pickle.load(f)
    return model_path, saved_args, chars, vocab

# 获取路径
def get_paths(input_path):
    if os.path.isfile(input_path):
        model_path = input_path
        save_dir = os.path.dirname(model_path)
    elif os.path.exists(input_path):
        save_dir = input_path
        checkpoint = tf.train.get_checkpoint_state(save_dir)
        if checkpoint:
            model_path = checkpoint.model_checkpoint_path
        else:
            raise ValueError('Checkpoint not found in {}.'.format(save_dir))
    else:
        raise ValueError('save_dir is not a valid path.')
    return model_path, os.path.join(save_dir, 'config.pkl'), os.path.join(save_dir, 'chars_vocab.pkl')

# 初始化模型
def init_model(saved_args, model_path):
    config = tf.compat.v1.ConfigProto()
    config.gpu_options.allow_growth = True
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    sess = tf.Session(config=config)
    with sess.as_default():
        tf.global_variables_initializer().run()
        net = Model(saved_args, True)
        saver = tf.train.Saver(net.save_variables_list())
        saver.restore(sess, model_path)
    return sess, net

class ChatbotGUI:
    def __init__(self, master):
        self.master = master
        master.title("Chatbot GUI")

        self.model_choice = tk.StringVar(value="GPT4All")
        self.model_choice.trace("w", self.change_model)

        self.model_gpt4all = GPT4All("orca-mini-3b-gguf2-q4_0.gguf")
        self.model_path, self.saved_args, self.chars, self.vocab = load_model_params('models/reddit')
        self.sess, self.net = init_model(self.saved_args, self.model_path)

        self.relevance = -1.
        self.temperature = 1.0
        self.topn = -1
        self.beam_width = 4

        self.states = initial_state_with_relevance_masking(self.net, self.sess, self.relevance)

        self.text_area = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=60, height=20)
        self.text_area.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

        self.input_entry = tk.Entry(master, width=50)
        self.input_entry.grid(row=1, column=0, padx=10, pady=10)

        self.submit_button = tk.Button(master, text="Submit", command=self.submit)
        self.submit_button.grid(row=1, column=1, padx=10, pady=10)

        self.clear_button = tk.Button(master, text="Clear", command=self.clear)
        self.clear_button.grid(row=1, column=2, padx=10, pady=10)

        self.model_selector = tk.OptionMenu(master, self.model_choice, "GPT4All", "Reddit")
        self.model_selector.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

        self.model = self.model_gpt4all

    def change_model(self, *args):
        if self.model_choice.get() == "GPT4All":
            self.model = self.model_gpt4all
        else:
            self.model = None
            self.states = initial_state_with_relevance_masking(self.net, self.sess, self.relevance)

    def submit(self):
        user_input = self.input_entry.get()
        self.text_area.insert(tk.END, f"\n> {user_input}\n")
        self.input_entry.delete(0, tk.END)

        if self.model_choice.get() == "GPT4All":
            if self.model is not None:
                with self.model.chat_session():
                    response = self.model.generate(user_input, max_tokens=1024)
                    self.text_area.insert(tk.END, response + "\n")
            else:
                messagebox.showerror("Error", "Model not initialized.")
        else:
            user_command_entered, reset, self.states, self.relevance, self.temperature, self.topn, self.beam_width = process_user_command(
                user_input, self.states, self.relevance, self.temperature, self.topn, self.beam_width)
            if reset:
                self.states = initial_state_with_relevance_masking(self.net, self.sess, self.relevance)

            if not user_command_entered:
                self.states = forward_text(self.net, self.sess, self.states, self.relevance, self.vocab, sanitize_text(self.vocab, "> " + user_input + "\n>"))
                computer_response_generator = beam_search_generator(sess=self.sess, net=self.net,
                    initial_state=copy.deepcopy(self.states), initial_sample=self.vocab[' '],
                    early_term_token=self.vocab['\n'], beam_width=self.beam_width, forward_model_fn=forward_with_mask,
                    forward_args={'relevance':self.relevance, 'mask_reset_token':self.vocab['\n'], 'forbidden_token':self.vocab['>'],
                                    'temperature':self.temperature, 'topn':self.topn})
                out_chars = []
                for i, char_token in enumerate(computer_response_generator):
                    out_chars.append(self.chars[char_token])
                    self.text_area.insert(tk.END, self.chars[char_token])  # 确保插入的是字符而不是索引
                    self.states = forward_text(self.net, self.sess, self.states, self.relevance, self.vocab, self.chars[char_token])
                    if i >= 500: break
                self.states = forward_text(self.net, self.sess, self.states, self.relevance, self.vocab, sanitize_text(self.vocab, "\n>"))

    def clear(self):
        self.text_area.delete(1.0, tk.END)
        self.states = initial_state_with_relevance_masking(self.net, self.sess, self.relevance)

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatbotGUI(root)
    root.mainloop()
