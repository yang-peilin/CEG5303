import time
from datasets import load_dataset
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.tokenize import word_tokenize
from gpt4all import GPT4All

# Download required NLTK resources (only needed the first time)
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')

# Initialize GPT4All model
model = GPT4All("orca-mini-3b-gguf2-q4_0.gguf")

# Load SQuAD dataset (you can change the number of samples)
dataset = load_dataset("squad", split="validation[:20]")

smoothie = SmoothingFunction().method4

total_score = 0
count = 0

print("\n===== Starting Evaluation =====\n")

for sample in dataset:
    question = sample["question"]
    references = sample["answers"]["text"]

    # Generate answer using GPT4All
    with model.chat_session():
        start = time.time()
        response = model.generate(question, max_tokens=100)
        end = time.time()

    # BLEU score calculation
    tokenized_refs = [word_tokenize(ref) for ref in references if ref.strip()]
    tokenized_candidate = word_tokenize(response)

    bleu = sentence_bleu(tokenized_refs, tokenized_candidate, smoothing_function=smoothie)
    total_score += bleu
    count += 1

    print(f"Q{count}: {question}")
    print(f"Reference Answers: {references}")
    print(f"Model Response: {response.strip()}")
    print(f"BLEU Score: {bleu:.4f}")
    print(f"Generation Time: {end - start:.2f} seconds\n")

# Average BLEU score
avg_score = total_score / count if count else 0
print(f"\nEvaluation Complete. Average BLEU Score: {avg_score:.4f}")
