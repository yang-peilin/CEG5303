Cf=2*1250*180/pi;
Cr=2*755*180/pi;
Iz=1536.7;
lf=1.015;
lr=1.895;
m=1270;
Ts=0.05;
v0_ego=20;
x0_ego=0;
y0_ego=0;
yaw0_ego=0;
Gi=16;

